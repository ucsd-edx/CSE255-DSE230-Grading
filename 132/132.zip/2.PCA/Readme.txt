The report is report.ipynb

The notebooks I have used are:
    2.Small_PCA_computation_CLASS.ipynb
    4.4 Weather Analysis - Visualisation.ipynb
    4.5 Weather Analysis - reconstruction PRCP.ipynb
    4.5 Weather Analysis - reconstruction SNWD.ipynb
    5. maps using iPyLeaflet.ipynb
    6. Is SNWD variation spatial or temporal?.ipynb
    7. Analyzing residuals.ipynb

I also changed several lines of the lib files.

Thank you.