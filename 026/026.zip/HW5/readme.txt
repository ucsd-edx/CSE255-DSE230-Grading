The hw5-report.ipynb in 2.PCA is my report for this homework.
