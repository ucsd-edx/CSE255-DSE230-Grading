Please refer to Report.ipynb as my final report.
Experiment.ipynb is used for some experiments apart from Professor's codes.

It is noticeable that the generated images are removed temporarily because of the submission limitation.
